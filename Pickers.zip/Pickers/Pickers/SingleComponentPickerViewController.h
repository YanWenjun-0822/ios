//
//  SingleComponentPickerViewController.h
//  Pickers
//
//  Created by 黄人煌 on 2019/11/24.
//  Copyright © 2019 黄人煌. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SingleComponentPickerViewController : UIViewController
/**
 此控制器类同时充当选取器的数据源和委托 因此需确保它遵循这两个角色的协议
 */
    <UIPickerViewDelegate,UIPickerViewDataSource>
@end

NS_ASSUME_NONNULL_END
