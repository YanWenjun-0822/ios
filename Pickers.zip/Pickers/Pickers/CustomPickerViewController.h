//
//  CustomPickerViewController.h
//  Pickers
//
//  Created by 黄人煌 on 2019/11/24.
//  Copyright © 2019 黄人煌. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomPickerViewController : UIViewController
<UIPickerViewDataSource,UIPickerViewDelegate>

@end

NS_ASSUME_NONNULL_END
