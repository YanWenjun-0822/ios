//
//  DoubleComponentPickerViewController.m
//  Pickers
//
//  Created by 黄人煌 on 2019/11/24.
//  Copyright © 2019 黄人煌. All rights reserved.
//

#import "DoubleComponentPickerViewController.h"
//定义代表各自选取器滚轮的两个索引值常量 最左边赋值为0 向右数字+1
#define kFillingComponent 0
#define kBreadComponent 1

@interface DoubleComponentPickerViewController ()
@property (weak, nonatomic) IBOutlet UIPickerView *doublePicker;
@property (strong, nonatomic) NSArray *fillingTypes;
@property (strong, nonatomic) NSArray *breadTypes;
@end

@implementation DoubleComponentPickerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.fillingTypes = @[@"Ham",@"Turkey",@"Peanut Butter",@"Tuna Salad",@"Chicken Salad",@"Roast Beef",@"Vegemite"];
    self.breadTypes = @[@"White",@"Whole Wheat",@"Rye",@"Sourdough",@"Seven Grain"];
}

- (IBAction)buttonPressed:(id)sender {
    NSInteger fillingRow = [self.doublePicker selectedRowInComponent:kFillingComponent];
    NSInteger breadRow = [self.doublePicker selectedRowInComponent:kBreadComponent];
    NSString *filling = self.fillingTypes[fillingRow];
    NSString *bread = self.breadTypes[breadRow];
    NSString *message = [[NSString alloc] initWithFormat:
                         @"Your %@ on %@ bread will be right up.",filling,bread];
    UIAlertController *alert =
    [UIAlertController
            alertControllerWithTitle:@"Thank you for youu order"
            message:message
            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"Great!"
                                style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}

/**
 添加委托方法和数据源方法
 */
/**
 数据源方法1：选取器询问应该显示几个滚轮
 这次想显示2个列表 所以返回2
 有一个UIPickerView作为参数传到这个方法中
 */
#pragma mark -
#pragma mark Picker Data Source Methods
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 2;
}
/**
 数据源方法2：询问给定的选取器滚轮应该包含多少行数据
 可通过参数知道当前询问的是哪个选取器视图，以及选择器询问的是哪个滚轮
 step1：检查选取器正在询问的是哪个滚轮 step2：返回相应数组的正确行数
 */
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if(component == kBreadComponent){
        return [self.breadTypes count];
    }else{
        return [self.fillingTypes count];
    }
}
/**
 委托方法3：选取器要求提供指定滚轮中指定的数据。
 参数提供了一个指向正在请求数据的选取器的指针，以及它请求的滚轮和行。
 请求选中的行时 需要使用前面定义的常量breadComponent和fillingComponent指定所请求的行所属的滚轮
 */
#pragma mark Picker Delegate Methods
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if(component == kBreadComponent){
        return self.breadTypes[row];
    }else{
        return self.fillingTypes[row];
    }
}


@end
