//
//  SingleComponentPickerViewController.m
//  Pickers
//
//  Created by 黄人煌 on 2019/11/24.
//  Copyright © 2019 黄人煌. All rights reserved.
//

#import "SingleComponentPickerViewController.h"

@interface SingleComponentPickerViewController ()
@property (weak, nonatomic) IBOutlet UIPickerView *singlePicker;
@property (strong, nonatomic) NSArray *characterNames; //添加一个数组

@end

@implementation SingleComponentPickerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //设定角色名数组的内容
    self.characterNames = @[@"Luck",@"Leia",@"Han",@"Chewbacca",@"Artoo",@"Threepio",@"Lando"];
}
- (IBAction)buttonPressed:(UIButton *)sender {
    //询问选取器当前选中的是哪一行 需要指定想要询问的滚轮 当我们传入0 即第一个滚轮的索引
    NSInteger row = [self.singlePicker selectedRowInComponent:0];
    
    NSString *selected = self.characterNames[row];
    NSString *title = [[NSString alloc] initWithFormat:@"You selected %@!",selected];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:@"Thank you for choosing." preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"You're welcome" style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}

/**
 通过三个方法实现选取器
 前2个方法来自UIPickerViewDataSource协议 所有选取器都必须实现这两个方法
 */
/**
 数据源方法1：选取器询问应该显示几个滚轮
 这次只想显示一个列表 所以返回1
 有一个UIPickerView作为参数传到这个方法中
 */
#pragma mark -
#pragma mark Picker Data Source Methods
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
/**
 数据源方法2：询问给定的选取器滚轮应该包含多少行数据
 可通过参数知道当前询问的是哪个选取器视图，以及选择器询问的是哪个滚轮
 因为只有一个选取器 只包含一个滚轮 所以可以直接返回数组中的对象数量
 */
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return [self.characterNames count];
}
/**
 委托方法3：选取器要求提供指定滚轮中指定的数据。
 参数提供了一个指向正在请求数据的选取器的指针，以及它请求的滚轮和行。
 由于我们的视图只有一个选取器 且该选取器只有一个滚轮，
 因此可以忽略除row参数之外的其他参数 使用row参数作为索引返回数组中相应的元素
 */
#pragma mark Picker Delegate Methods
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return self.characterNames[row];
}


@end
