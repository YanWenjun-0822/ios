//
//  ViewController.m
//  Pickers
//
//  Created by 黄人煌 on 2019/11/24.
//  Copyright © 2019 黄人煌. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
