//
//  CustomPickerViewController.m
//  Pickers
//
//  Created by 黄人煌 on 2019/11/24.
//  Copyright © 2019 黄人煌. All rights reserved.
//

#import "CustomPickerViewController.h"
//要使用声音 就要访问iOS Audio Toolbox中的类
#import "AudioToolbox/AudioToolbox.h"

@interface CustomPickerViewController ()

@property (strong, nonatomic) NSArray *images;//添加一个NSArray对象属性 包含了老虎机转盘上的图案
@property (weak, nonatomic) IBOutlet UILabel *winLabel;
@property (weak, nonatomic) IBOutlet UIPickerView *picker;
@property (weak, nonatomic) IBOutlet UIButton *button;//添加一个关联到Spin按钮的输出接口
@property (assign, nonatomic) SystemSoundID winSoundID;
@property (assign, nonatomic) SystemSoundID crunchSoundID;


@end

@implementation CustomPickerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.images = @[[UIImage imageNamed:@"seven"],
                    [UIImage imageNamed:@"bar"],
                    [UIImage imageNamed:@"crown"],
                    [UIImage imageNamed:@"cherry"],
                    [UIImage imageNamed:@"lemon"],
                    [UIImage imageNamed:@"apple"]];
    self.winLabel.text = @" ";//确保便签内容是个空格 这样可以确保它以正确的高度显示
}

/**
 使用win判断一行中是否出现了3个连续相同的图像 如果是 win设置为YES
 使用numInRow跟踪目前一行中连续相同的值出现的次数
 在lastVal中记录前一个滚轮的值 以便与当前值比较
 */
- (IBAction)spin:(id)sender {
    BOOL win = NO;
    int numInRow = 1;
    int lastVal = -1;
    //使用循环把所有五个滚轮的当前值都设置为一个新的随机航 根据images数组的元素个数来选取随机数
    for(int i = 0;i<5;i++){
        int newValue = arc4random_uniform((uint)[self.images count]);
        if(newValue == lastVal){//新值与前一个比较 匹配 +1
            numInRow++;
        }else{
            numInRow = 1;//不匹配 重置为1 然后把新值赋给lastVal
        }
        lastVal= newValue;
        //将相应的滚轮设置为新值 通知这个滚轮使用动画效果进行改变 并通知选取器重新加载这个滚轮
        [self.picker selectRow:newValue inComponent:i animated:YES];
        [self.picker reloadComponent:i];
        if(numInRow >= 3){//使用win判断一行中是否出现了3个连续相同的图像 如果是 win设置为YES
            win = YES;
        }
    }
    if(_crunchSoundID == 0){
        NSString *path = [[NSBundle mainBundle] pathForResource:@"crunch"
                                                         ofType:@"wav"];
        NSURL *soundURL = [NSURL fileURLWithPath:path];
        AudioServicesCreateSystemSoundID((__bridge CFURLRef)soundURL,
                                        &_crunchSoundID);
    }
    AudioServicesPlaySystemSound(_crunchSoundID);
    if(win){
        [self performSelector:@selector(playWinSound)
                   withObject:nil
                   afterDelay:.5];
    }else{
        [self performSelector:@selector(showButton)
                   withObject:nil
                   afterDelay:.5];
    }
    self.button.hidden = YES;
    self.winLabel.text = @" ";
    /*
     if(win){
        self.winLabel.text = @"WINNER!";
    }else{
        self.winLabel.text = @" ";
    }
     */
}


/**
添加委托方法和数据源方法
*/
/**
 数据源方法1：选取器询问应该显示几个滚轮
 有一个UIPickerView作为参数传到这个方法中
 */
#pragma mark -
#pragma mark Picker Data Source Methods
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 5;
}
/**
 数据源方法2：询问给定的选取器滚轮应该包含多少行数据
 可通过参数知道当前询问的是哪个选取器视图，以及选择器询问的是哪个滚轮
 */
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return [self.images count];
}
/**
 委托方法3：选取器要求提供指定滚轮中指定的数据。
 参数提供了一个指向正在请求数据的选取器的指针，以及它请求的滚轮和行。
 请求选中的行时 需要使用前面定义的常量breadComponent和fillingComponent指定所请求的行所属的滚轮
 */
#pragma mark Picker Delegate Methods
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UIImage *image = self.images[row];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
    return imageView;
}

-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return 64;
}
//方法1：显示按钮
- (void)showButton{
    self.button.hidden = NO;
}
//方法2：在用户获胜时调用
- (void)playWinSound{
    if(_winSoundID == 0){//检查声音是否加载完成
        //首先向程序包请求名为win.war的声音文件路径
        NSURL *soundURL = [[NSBundle mainBundle] URLForResource:@"win"
                                                  withExtension:@"wav"];
        AudioServicesCreateSystemSoundID((__bridge CFURLRef)soundURL,
                                        &_winSoundID);
    }
    AudioServicesPlaySystemSound(_winSoundID);
    self.winLabel.text = @"WINNER!";
    //1.5s后调用showButton方法 确保刻度盘到最终位置之后才将结果告知
    [self performSelector:@selector(showButton)
               withObject:nil
               afterDelay:1.5];
}
@end
