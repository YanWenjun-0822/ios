//
//  DependentComponentPickerViewController.m
//  Pickers
//
//  Created by 黄人煌 on 2019/11/24.
//  Copyright © 2019 黄人煌. All rights reserved.
//

#import "DependentComponentPickerViewController.h"
#define kStateComponent 0
#define kZipComponent 1

@interface DependentComponentPickerViewController ()

@property (strong, nonatomic) NSDictionary *stateZips;
@property (strong, nonatomic) NSArray *states;
@property (strong, nonatomic) NSArray *zips;
@property (weak, nonatomic) IBOutlet UIPickerView *dependentPicker;


@end

@implementation DependentComponentPickerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //获得应用程序包的引用
    NSBundle *bundle = [NSBundle mainBundle];
    //使用包获取所需资源的路径 此处返回一个URL 内容是statedictionary.plist的位置 然后使用这个URL加载字典
    NSURL *plistURL = [bundle URLForResource:@"statedictionary"
                               withExtension:@"plist"];
    self.stateZips = [NSDictionary
                      dictionaryWithContentsOfURL:plistURL];
    NSArray *allStates = [self.stateZips allKeys];
    NSArray *sortedStated = [allStates sortedArrayUsingSelector:
                             @selector(compare:)];
    self.states = sortedStated;
    NSString *selectedState = self.states[0];
    self.zips = self.stateZips[selectedState];
    
}
- (IBAction)buttonPressed:(id)sender {
    NSInteger stateRow = [self.dependentPicker
                          selectedRowInComponent:kStateComponent];
    NSInteger zipRow = [self.dependentPicker
                        selectedRowInComponent:kZipComponent];
    NSString *state = self.states[stateRow];
    NSString *zip = self.zips[zipRow];
    NSString *title = [[NSString alloc] initWithFormat:@"You selected zip code %@.", zip];
    NSString *message = [[NSString alloc] initWithFormat:@"%@ is in %@", zip, state];
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:title
                    message:message
                    preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK"
                        style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}

/**
 添加委托方法和数据源方法
 */
/**
 数据源方法1：选取器询问应该显示几个滚轮
 这次想显示2个列表 所以返回2
 有一个UIPickerView作为参数传到这个方法中
 */
#pragma mark -
#pragma mark Picker Data Source Methods
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 2;
}
/**
 数据源方法2：询问给定的选取器滚轮应该包含多少行数据
 可通过参数知道当前询问的是哪个选取器视图，以及选择器询问的是哪个滚轮
 step1：检查选取器正在询问的是哪个滚轮 step2：返回相应数组的正确行数
 */
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if(component == kStateComponent){
        return [self.states count];
    }else{
        return [self.zips count];
    }
}
/**
 委托方法3：选取器要求提供指定滚轮中指定的数据。
 参数提供了一个指向正在请求数据的选取器的指针，以及它请求的滚轮和行。
 请求选中的行时 需要使用前面定义的常量breadComponent和fillingComponent指定所请求的行所属的滚轮
 */
#pragma mark Picker Delegate Methods
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if(component == kStateComponent){
        return self.states[row];
    }else{
        return self.zips[row];
    }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if(component == kStateComponent){
        NSString *selectedState = self.states[row];
        self.zips = self.stateZips[selectedState];
        [self.dependentPicker reloadComponent:kZipComponent];
        [self.dependentPicker selectRow:0
                            inComponent:kZipComponent
                               animated:YES];
    }
}

//调整滚轮的宽度值 让州名选取器占用三分之二的宽度
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
    CGFloat pickerWidth = pickerView.bounds.size.width;
    if(component == kZipComponent){
        return pickerWidth/3;
    }else{
        return 2*pickerWidth/3;
    }
}
@end
