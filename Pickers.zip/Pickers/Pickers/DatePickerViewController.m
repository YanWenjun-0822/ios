//
//  DatePickerViewController.m
//  Pickers
//
//  Created by 黄人煌 on 2019/11/24.
//  Copyright © 2019 黄人煌. All rights reserved.
//

#import "DatePickerViewController.h"

@interface DatePickerViewController ()
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
- (IBAction)buttonPressed:(UIButton *)sender;

@end

@implementation DatePickerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    /**
     创建一个新的NSDate对象 通过这种方式创建的NSDate对象将包含当前的日期和时间
     然后将datePicker设置为这个日期 从而确保每次从storyboard中加载此视图时 选取器都会重置为当前的日期和时间
     */
    NSDate *now = [NSDate date];
    [self.datePicker setDate:now animated:NO];
    
}

/**
 使用datePicker接口从日期选择器中获取当前的日期值
 根据该日期构造一个字符串
 将字符串显示在警告界面中
 */
- (IBAction)buttonPressed:(UIButton *)sender {
    NSDate *date = self.datePicker.date;
    NSString *message = [[NSString alloc] initWithFormat:
                         @"The date and time you selected is %@",date];
    UIAlertController *alert =
            [UIAlertController alertControllerWithTitle:
                    @"Date and Time Selected"
                    message:message
                    preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action =
            [UIAlertAction actionWithTitle:@"That's so true!"
                    style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}
@end
